# MainProject-SellAnything
ER Diagram
![](screenshot/erd.jpeg)
Homepage
![](screenshot/1.png)
User Login
![](screenshot/2.png)
Create new Post
![](screenshot/3.png)
Admin Panel
![](screenshot/4.png)
My products
![](screenshot/5.png)
User Registration
![](screenshot/6.png)
Edit Profile
![](screenshot/7.png)
          

